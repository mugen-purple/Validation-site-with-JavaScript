function check(){
let name = document.getElementById('name').value;
let email = document.getElementById('email').value;
let date = document.getElementById('date').value;
let password = document.getElementById('password').value;
let someVoid = (name === ''|| name === ' ' || email === '' || date === '' || password === '' || password === ' ');
let hasUpper = /[A-Z]/.test(password);
let hasLower = /[a-z]/.test(password);
let hasNumber = /[0-9]/.test(password);
let z = document.getElementById('msg');
let x = document.getElementById('pass');
let minLength = password.length >= 8;
if (someVoid){
z.textContent = "Make sure all files are filed in.";
z.style.color = "red";
z.style.textShadow = "1px 1px 0 black, -1px 1px 0 black, 1px -1px 0 black, -1px -1px 0 black";
} else{
z.textContent = ""; 
}
if (hasNumber && hasLower && hasUpper && minLength){
x.textContent = ""; 
} else{
x.textContent = "Make sure your password has at least one uppercase letter, one number, and eight characters.";
x.style.color = "yellow";
x.style.textShadow = "1px 1px 0 black, -1px 1px 0 black, 1px -1px 0 black, -1px -1px 0 black";

}

}  



